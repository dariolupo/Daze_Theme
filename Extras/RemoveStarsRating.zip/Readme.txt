This is a modified template file to remove the stars rating system appearing on the bottom of the covers.

How to:
Copy and replace the file (GridViewItemTemplate.xaml) to DazeThemeInstallationFolder\DerivedStyles\

Backup the old one in case you wish to invert the changes.